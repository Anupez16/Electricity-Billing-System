package electricity.billing.system;

import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;

public class bill_details extends JFrame {
    String meter;

    bill_details(String meter) {
        this.meter = meter;
        setSize(700, 650);
        setLocation(400, 150);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JTable table = new JTable();

        try {
            database c = new database();
            String query_bill = "SELECT month, units_consumed, total_bill, status FROM bill WHERE meter_no = '" + meter + "'";
            ResultSet resultSet = c.statement.executeQuery(query_bill);

            if (resultSet.isBeforeFirst()) { // Check if data exists without moving cursor
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } else {
                JOptionPane.showMessageDialog(this, "No bill details found for this meter number.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving bill details.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0, 0, 700, 650);
        add(sp);

        setVisible(true);
    }

    public static void main(String[] args) {
        new bill_details("");  // Pass a valid meter number for testing
    }
}
