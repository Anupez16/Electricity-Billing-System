package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

public class calculate_bill extends JFrame implements ActionListener {
    JLabel nameText, addressText;
    TextField unitText;
    Choice meternumCho, monthCho;
    JButton submit, cancel;
    database c; // Single instance of database connection

    calculate_bill() {
        c = new database(); // Initialize the database connection once

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(214, 195, 247));
        add(panel);

        JLabel heading = new JLabel("Calculate Electricity Bill");
        heading.setBounds(70, 10, 300, 20);
        heading.setFont(new Font("Tahoma", Font.BOLD, 20));
        panel.add(heading);

        JLabel meternum = new JLabel("Meter Number");
        meternum.setBounds(50, 80, 100, 20);
        panel.add(meternum);

        meternumCho = new Choice();
        loadMeterNumbers();
        meternumCho.setBounds(180, 80, 100, 20);
        panel.add(meternumCho);

        JLabel name = new JLabel("Name");
        name.setBounds(50, 120, 100, 20);
        panel.add(name);

        nameText = new JLabel("");
        nameText.setBounds(180, 120, 150, 20);
        panel.add(nameText);

        JLabel address = new JLabel("Address");
        address.setBounds(50, 160, 100, 20);
        panel.add(address);

        addressText = new JLabel("");
        addressText.setBounds(180, 160, 150, 20);
        panel.add(addressText);

        // Fetch customer details based on meter number selection
        loadCustomerDetails();

        meternumCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                loadCustomerDetails();
            }
        });

        JLabel unitconsumed = new JLabel("Unit Consumed");
        unitconsumed.setBounds(50, 200, 100, 20);
        panel.add(unitconsumed);

        unitText = new TextField();
        unitText.setBounds(180, 200, 150, 20);
        panel.add(unitText);

        JLabel month = new JLabel("Month");
        month.setBounds(50, 240, 100, 20);
        panel.add(month);

        monthCho = new Choice();
        String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        for (String m : months) {
            monthCho.add(m);
        }
        monthCho.setBounds(180, 240, 150, 20);
        panel.add(monthCho);

        submit = new JButton("Submit");
        submit.setBounds(80, 300, 100, 25);
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        panel.add(submit);

        cancel = new JButton("Cancel");
        cancel.setBounds(220, 300, 100, 25);
        cancel.setBackground(Color.black);
        cancel.setForeground(Color.white);
        cancel.addActionListener(this);
        panel.add(cancel);

        setLayout(new BorderLayout());
        add(panel, "Center");

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/budget.png"));
        Image image = imageIcon.getImage().getScaledInstance(250, 200, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel imageLabel = new JLabel(imageIcon1);
        add(imageLabel, "East");

        setSize(650, 400);
        setLocation(400, 200);
        setVisible(true);
    }

    private void loadMeterNumbers() {
        try {
            ResultSet resultSet = c.statement.executeQuery("SELECT meter_no FROM new_customer");
            while (resultSet.next()) {
                meternumCho.add(resultSet.getString("meter_no"));
            }
            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadCustomerDetails() {
        try {
            PreparedStatement pstmt = c.connection.prepareStatement("SELECT name, address FROM new_customer WHERE meter_no = ?");
            pstmt.setString(1, meternumCho.getSelectedItem());
            ResultSet resultSet = pstmt.executeQuery();
            if (resultSet.next()) {
                nameText.setText(resultSet.getString("name"));
                addressText.setText(resultSet.getString("address"));
            }
            resultSet.close();
            pstmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            String smeterNo = meternumCho.getSelectedItem();
            String sunit = unitText.getText().trim();
            String smonth = monthCho.getSelectedItem();

            if (sunit.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter the number of units consumed.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int units = Integer.parseInt(sunit);
                int totalBill = calculateTotalBill(units);

                String query_total_bill = "INSERT INTO bill (meter_no, month, units_consumed, total_bill, status) VALUES (?, ?, ?, ?, 'Not Paid')";
                PreparedStatement pstmt = c.connection.prepareStatement(query_total_bill);
                pstmt.setString(1, smeterNo);
                pstmt.setString(2, smonth);
                pstmt.setInt(3, units);
                pstmt.setInt(4, totalBill);
                pstmt.executeUpdate();
                pstmt.close();

                JOptionPane.showMessageDialog(null, "Customer Bill Updated Successfully");
                setVisible(false);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid numeric value for units.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            setVisible(false);
        }
    }

    private int calculateTotalBill(int units) throws SQLException {
        int totalBill = 0;
        String query_tax = "SELECT * FROM tax";
        PreparedStatement pstmt = c.connection.prepareStatement(query_tax);
        ResultSet resultSet = pstmt.executeQuery();
        if (resultSet.next()) {
            totalBill += units * resultSet.getInt("cost_per_unit");
            totalBill += resultSet.getInt("meter_rent");
            totalBill += resultSet.getInt("service_charge");
            totalBill += resultSet.getInt("swacch_bharat");
            totalBill += resultSet.getInt("fixed_tax");
        }
        resultSet.close();
        pstmt.close();
        return totalBill;
    }

    public static void main(String[] args) {
        new calculate_bill();
    }
}
