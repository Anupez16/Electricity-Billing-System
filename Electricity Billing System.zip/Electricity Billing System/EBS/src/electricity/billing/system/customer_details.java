package electricity.billing.system;

import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.sql.ResultSet;

public class customer_details extends JFrame implements ActionListener {
    Choice searchMeterCho, searchNameCho;
    JTable table;
    JButton search, print, close;
    database c;

    customer_details() {
        super("Customer Details");
        getContentPane().setBackground(new Color(192, 186, 254));
        setSize(700, 500);
        setLocation(400, 200);
        setLayout(null);

        c = new database();  // Single instance of database

        JLabel searchMeter = new JLabel("Search By Meter Number");
        searchMeter.setBounds(20, 20, 180, 20);
        add(searchMeter);

        searchMeterCho = new Choice();
        searchMeterCho.setBounds(200, 20, 150, 20);
        add(searchMeterCho);

        JLabel searchName = new JLabel("Search By Name");
        searchName.setBounds(400, 20, 120, 20);
        add(searchName);

        searchNameCho = new Choice();
        searchNameCho.setBounds(520, 20, 150, 20);
        add(searchNameCho);

        loadChoices(); // Populate dropdowns

        table = new JTable();
        loadTableData("SELECT * FROM new_customer"); // Load initial data

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 100, 700, 350);
        add(scrollPane);

        search = new JButton("Search");
        search.setBackground(Color.white);
        search.setBounds(20, 70, 100, 25);
        search.addActionListener(this);
        add(search);

        print = new JButton("Print");
        print.setBackground(Color.white);
        print.setBounds(140, 70, 100, 25);
        print.addActionListener(this);
        add(print);

        close = new JButton("Close");
        close.setBackground(Color.white);
        close.setBounds(600, 70, 100, 25);
        close.addActionListener(this);
        add(close);

        setVisible(true);
    }

    private void loadChoices() {
        try {
            ResultSet rs = c.statement.executeQuery("SELECT meter_no, name FROM new_customer");
            while (rs.next()) {
                searchMeterCho.add(rs.getString("meter_no"));
                searchNameCho.add(rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadTableData(String query) {
        try {
            ResultSet rs = c.statement.executeQuery(query);
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == search) {
            String meterNo = searchMeterCho.getSelectedItem();
            String name = searchNameCho.getSelectedItem();

            String query = "SELECT * FROM new_customer WHERE 1=1";
            if (meterNo != null && !meterNo.isEmpty()) {
                query += " AND meter_no = '" + meterNo + "'";
            }
            if (name != null && !name.isEmpty()) {
                query += " AND name = '" + name + "'";
            }

            loadTableData(query);

        } else if (e.getSource() == print) {
            try {
                table.print();
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Printing Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == close) {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new customer_details();
    }
}
