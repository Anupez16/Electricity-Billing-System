package electricity.billing.system;

import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class deposit_details extends JFrame implements ActionListener {
    Choice searchMeterCho, searchMonthCho;
    JTable table;
    JButton search, print, close;

    deposit_details() {
        super("Deposit Details");
        getContentPane().setBackground(new Color(192, 186, 254));
        setSize(700, 500);
        setLocation(400, 200);
        setLayout(null);

        JLabel searchMeter = new JLabel("Search By Meter Number");
        searchMeter.setBounds(20, 20, 150, 20);
        add(searchMeter);

        searchMeterCho = new Choice();
        searchMeterCho.setBounds(180, 20, 150, 20);
        add(searchMeterCho);

        // Load unique meter numbers
        loadMeterNumbers();

        JLabel searchMonth = new JLabel("Search By Month");
        searchMonth.setBounds(400, 20, 120, 20);
        add(searchMonth);

        searchMonthCho = new Choice();
        String[] months = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        for (String month : months) {
            searchMonthCho.add(month);
        }
        searchMonthCho.setBounds(520, 20, 150, 20);
        add(searchMonthCho);

        table = new JTable();
        loadAllBills(); // Load all bills on startup

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 100, 700, 350);
        add(scrollPane);

        search = new JButton("Search");
        search.setBackground(Color.white);
        search.setBounds(20, 70, 80, 20);
        search.addActionListener(this);
        add(search);

        print = new JButton("Print");
        print.setBackground(Color.white);
        print.setBounds(120, 70, 80, 20);
        print.addActionListener(this);
        add(print);

        close = new JButton("Close");
        close.setBackground(Color.white);
        close.setBounds(600, 70, 80, 20);
        close.addActionListener(this);
        add(close);

        setVisible(true);
    }

    private void loadMeterNumbers() {
        database db = new database();
        Set<String> uniqueMeters = new HashSet<>();

        try {
            ResultSet resultSet = db.statement.executeQuery("SELECT DISTINCT meter_no FROM bill");
            while (resultSet.next()) {
                uniqueMeters.add(resultSet.getString("meter_no"));
            }
            for (String meter : uniqueMeters) {
                searchMeterCho.add(meter);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadAllBills() {
        database db = new database();
        try {
            ResultSet resultSet = db.statement.executeQuery("SELECT * FROM bill");
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        database db = new database();

        if (e.getSource() == search) {
            String query_search = "SELECT * FROM bill WHERE meter_no = ? AND month = ?";
            try (PreparedStatement preparedStatement = db.connection.prepareStatement(query_search)) {
                preparedStatement.setString(1, searchMeterCho.getSelectedItem());
                preparedStatement.setString(2, searchMonthCho.getSelectedItem());

                ResultSet resultSet = preparedStatement.executeQuery();
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == print) {
            try {
                table.print();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new deposit_details();
    }
}
