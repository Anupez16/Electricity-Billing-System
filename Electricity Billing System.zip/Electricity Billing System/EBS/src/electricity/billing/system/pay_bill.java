package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

public class pay_bill extends JFrame implements ActionListener {
    Choice searchmonthcho;
    String meter;
    JButton pay, back;
    JLabel unitText, totalBillText, statusText;

    pay_bill(String meter) {
        this.meter = meter;
        setSize(900, 600);
        setLocation(300, 150);
        setLayout(null);

        JLabel heading = new JLabel("Pay Bill");
        heading.setFont(new Font("Tahoma", Font.BOLD, 24));
        heading.setBounds(120, 5, 400, 30);
        add(heading);

        JLabel meterNumber = new JLabel("Meter Number");
        meterNumber.setBounds(35, 80, 200, 20);
        add(meterNumber);

        JLabel meterNumberText = new JLabel(meter);
        meterNumberText.setBounds(300, 80, 200, 20);
        add(meterNumberText);

        JLabel name = new JLabel("Name");
        name.setBounds(35, 140, 200, 20);
        add(name);

        JLabel nameText = new JLabel("");
        nameText.setBounds(300, 140, 200, 20);
        add(nameText);

        JLabel month = new JLabel("Month");
        month.setBounds(35, 200, 200, 20);
        add(month);

        searchmonthcho = new Choice();
        String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        for (String m : months) {
            searchmonthcho.add(m);
        }
        searchmonthcho.setBounds(300, 200, 150, 20);
        add(searchmonthcho);

        JLabel unit = new JLabel("Units Consumed");
        unit.setBounds(35, 260, 200, 20);
        add(unit);

        unitText = new JLabel("N/A");
        unitText.setBounds(300, 260, 200, 20);
        add(unitText);

        JLabel totalBill = new JLabel("Total Bill");
        totalBill.setBounds(35, 320, 200, 20);
        add(totalBill);

        totalBillText = new JLabel("N/A");
        totalBillText.setBounds(300, 320, 200, 20);
        add(totalBillText);

        JLabel status = new JLabel("Status");
        status.setBounds(35, 380, 200, 20);
        add(status);

        statusText = new JLabel("N/A");
        statusText.setBounds(300, 380, 200, 20);
        statusText.setForeground(Color.RED);
        add(statusText);

        // Fetch customer name
        try {
            database c = new database();
            ResultSet resultSet = c.statement.executeQuery("SELECT name FROM new_customer WHERE meter_no = '" + meter + "'");
            if (resultSet.next()) {
                nameText.setText(resultSet.getString("name"));
            }
            resultSet.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Update details when a month is selected
        searchmonthcho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                updateBillDetails();
            }
        });

        pay = new JButton("Pay");
        pay.setBackground(Color.black);
        pay.setForeground(Color.white);
        pay.setBounds(100, 460, 100, 25);
        pay.addActionListener(this);
        add(pay);

        back = new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.setBounds(230, 460, 100, 25);
        back.addActionListener(this);
        add(back);

        setVisible(true);
    }

    private void updateBillDetails() {
        try {
            database c = new database();
            String selectedMonth = searchmonthcho.getSelectedItem();
            String query = "SELECT units_consumed, total_bill, status FROM bill WHERE meter_no = ? AND month = ?";
            PreparedStatement pstmt = c.connection.prepareStatement(query);
            pstmt.setString(1, meter);
            pstmt.setString(2, selectedMonth);
            ResultSet resultSet = pstmt.executeQuery();

            if (resultSet.next()) {
                String units = resultSet.getString("units_consumed");
                String totalBill = resultSet.getString("total_bill");
                String status = resultSet.getString("status");

                // Debugging Log
                System.out.println("Debug: units_consumed - " + units);
                System.out.println("Debug: total_bill - " + totalBill);
                System.out.println("Debug: status - " + status);

                // Handle Null Values
                unitText.setText(units != null ? units : "No Data");
                totalBillText.setText(totalBill != null ? totalBill : "No Data");
                statusText.setText(status != null ? status : "No Data");
            } else {
                System.out.println("Debug: No matching record found!");
                unitText.setText("N/A");
                totalBillText.setText("N/A");
                statusText.setText("No Bill Found");
            }
            resultSet.close();
            pstmt.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == pay) {
            try {
                database c = new database();
                String selectedMonth = searchmonthcho.getSelectedItem();
                String query = "UPDATE bill SET status = 'Paid' WHERE meter_no = ? AND month = ?";
                PreparedStatement pstmt = c.connection.prepareStatement(query);
                pstmt.setString(1, meter);
                pstmt.setString(2, selectedMonth);
                int rowsUpdated = pstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Bill Paid Successfully!");
                    updateBillDetails(); // Refresh status
                } else {
                    JOptionPane.showMessageDialog(this, "No bill found for this month!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                pstmt.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new pay_bill("123456"); // Example meter number
    }
}
