package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;

public class payment_bill extends JFrame implements ActionListener {
    JButton payOnline, back;
    String meter;

    payment_bill(String meter) {
        this.meter = meter;
        setTitle("Payment Portal");
        setSize(400, 250);
        setLocation(500, 250);
        setLayout(new FlowLayout());

        JLabel message = new JLabel("Click below to proceed with payment:");
        add(message);

        payOnline = new JButton("Pay Now (Paytm)");
        payOnline.addActionListener(this);
        add(payOnline);

        back = new JButton("Back");
        back.addActionListener(this);
        add(back);

        setVisible(true);

        // Try opening Paytm automatically
        openPaytm();
    }

    private void openPaytm() {
        try {
            Desktop.getDesktop().browse(new URI("https://paytm.com/online-payments"));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to open Paytm. Click 'Pay Now' instead.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == payOnline) {
            openPaytm();
        } else if (e.getSource() == back) {
            setVisible(false);
            new pay_bill(meter); // Ensure pay_bill.java exists
        }
    }

    public static void main(String[] args) {
        new payment_bill("");
    }
}
